﻿using HarmonyLib;
using iiMenu.Mods.Spammers;
using Photon.Pun;
using PlayFab.ExperimentationModels;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using System.Diagnostics;
using static StupidTemplate.Settings;

namespace StupidTemplate.Menu
{
    //the new new new frwosty menu PAID
    internal class Buttons
    {

        public static PhotonView rig2view(VRRig p)
        {
            return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
        }

        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods 0
                new ButtonInfo { buttonText = "Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = "Opens the main settings page for the menu."},
                new ButtonInfo { buttonText = "Disguise", method =() => basicMods.ChangeIdentity(), isTogglable = false , toolTip = "Disguises you"},
                new ButtonInfo { buttonText = "Quit Gtag [<color=green>W/UND</color>]", method =() => basicMods.Quit(), isTogglable = false , toolTip = "Quits Ur Game"},
                new ButtonInfo { buttonText = "Disconnect [<color=green>W/UND</color>]", method =() => basicMods.Discnt(), isTogglable = false, toolTip = "Disconnects you from the lobby"},
                new ButtonInfo { buttonText = "Join Random [<color=green>W/UND</color>]", method =() => basicMods.JoinRandom(), isTogglable = false, toolTip = "Joins A random Public"},
                new ButtonInfo { buttonText = "Create Public", method =() => basicMods.CreatePublic()},
                new ButtonInfo { buttonText = "Platforms [<color=green>W/UND</color>]", method = () => basicMods.Plats(), toolTip = "Enables Platforms"},
                new ButtonInfo { buttonText = "Sticky Platforms [<color=green>W/UND</color>]", method =() => basicMods.StickyPlats() , toolTip = "Enables Sticky Platforms"},
                new ButtonInfo { buttonText = "Invis Platforms [<color=green>W/UND</color>]", method =() => basicMods.InvisPlats(), toolTip = "Enables Invisible Platforms" },
                new ButtonInfo { buttonText = "Fly [<color=green>W/UND</color>]", method =() => basicMods.Fly(), toolTip = "Fly!"  },
                new ButtonInfo { buttonText = "Slow Fly [<color=green>W/UND</color>]", method =() => basicMods.SlowFly() },
                new ButtonInfo { buttonText = "Trigger Fly [<color=green>W/UND</color>]", method =() => basicMods.TriggerFly() },
                new ButtonInfo { buttonText = "Fast Fly [<color=green>W/UND</color>]", method =() => basicMods.FastFly() },
                new ButtonInfo { buttonText = "Bark Fly", method =() => basicMods.BarkFly() },
                new ButtonInfo { buttonText = "Primary Disconnect [<color=green>W/UND</color>]", method =() => basicMods.PrimaryDiscnt() },
                new ButtonInfo { buttonText = "Invis Monke [<color=green>LT/W/UND</color>]", method =() => basicMods.InvisMonke()},
                new ButtonInfo { buttonText = "Ghost Monke [<color=green>W/UND</color>]", method =() => basicMods.GhostCam() },
                new ButtonInfo { buttonText = "Rig Gun", method =() => basicMods.RigGun() },
                new ButtonInfo { buttonText = "Fake Lag [<color=green>W/UND</color>]", method =() => basicMods.LaggyRig(),},
                new ButtonInfo { buttonText = "Noclip [<color=green>LT/W/UND</color>]", method =() => basicMods.Noclip() },
                new ButtonInfo { buttonText = "Noclip With Plats [<color=green>LT/W/UND</color>]", method =() => basicMods.Noclipwplats()},
                new ButtonInfo { buttonText = "Steam LongArms [<color=green>W/UND</color>]", method =() => basicMods.LongArms(), disableMethod =() => basicMods.ResetArms()},
                new ButtonInfo { buttonText = "Legit Arms [<color=green>W/UND</color>]", method =() => basicMods.LegitArms(), disableMethod =() => basicMods.ResetArms()},
                new ButtonInfo { buttonText = "SpeedBoost [<color=green>W/UND</color>]", method =() => basicMods.Speedboost()},
                new ButtonInfo { buttonText = "Mosa Boost [<color=green>W/UND</color>]", method =() => basicMods.Mosaboost()},
                new ButtonInfo { buttonText = "60 HZ [<color=green>W/UND</color>]", method =() => basicMods.ForceLagGame()},
                new ButtonInfo { buttonText = "No Tag On Join [<color=green>W/UND</color>]", method =() => basicMods.NoTagOnJoinMEOWW()},
                new ButtonInfo { buttonText = "Tag Self [<color=green>W/UND</color>]", method =() => basicMods.TagSelf(), isTogglable =  false},
                new ButtonInfo { buttonText = "UnTag Self [<color=red>M</color>]", method =() => basicMods.UntagSelf()},
                new ButtonInfo { buttonText = "Tag All Loop", method =() => basicMods.TagBot()},
                new ButtonInfo { buttonText = "Tag All", method =() => basicMods.TagAll()},
                new ButtonInfo { buttonText = "Tag Gun", method =() => LongMods.TagGun()},
                new ButtonInfo { buttonText = "Hunt Tag All", method =() => basicMods.TagAllHunt()},
                new ButtonInfo { buttonText = "Set Time Day [<color=green>W/UND</color>]", method =() => basicMods.WiggerTime(), isTogglable = false},
                new ButtonInfo { buttonText = "Set Time Night [<color=green>W/UND</color>]", method =() => basicMods.NiggerTime(), isTogglable = false},
                new ButtonInfo { buttonText = "Slide Control [<color=green>W/UND</color>]", method =() => basicMods.EnableSlideControl(),disableMethod =() => basicMods.DisableSlideControl()},
                new ButtonInfo { buttonText = "Grab Bug [<color=green>RG/W/UND</color>]", method =() => basicMods.GrabBug()},
                new ButtonInfo { buttonText = "Grab Bat [<color=green>LG/W/UND</color>]", method =() => basicMods.GrabBat()},
                new ButtonInfo { buttonText = "Grab BeachBall [<color=green>RG/W/UND</color>]", method =() => basicMods.GrabBeachBall()},
                new ButtonInfo { buttonText = "Bug Gun [<color=Yellow>O</color>]", method =() => basicMods.BugGun()},
                new ButtonInfo { buttonText = "Bat Gun [<color=Yellow>O</color>]", method =() => basicMods.BatGun()},
                new ButtonInfo { buttonText = "BeachBall Gun [<color=Yellow>O</color>]", method =() => basicMods.BeachBallGun()},
                new ButtonInfo { buttonText = "Hide Bug [<color=Yellow>O</color>]", method =() => basicMods.DestroyBug()},
                new ButtonInfo { buttonText = "Hide Bat [<color=Yellow>O</color>]", method =() => basicMods.DestroyBat()},
                new ButtonInfo { buttonText = "Hide BeachBall [<color=Yellow>O</color>]", method =() => basicMods.DestroyBeachBall()},
                new ButtonInfo { buttonText = "Eel Spam", method =() => AnoyyingMods.Ear()},
                new ButtonInfo { buttonText = "Metal Spam", method =() => AnoyyingMods.Metal()},
                new ButtonInfo { buttonText = "Crystal Spam", method =() => AnoyyingMods.Crystal()},
                new ButtonInfo { buttonText = "Huge Crystal Spam", method =() => AnoyyingMods.HugeCrystal()},
                new ButtonInfo { buttonText = "Random Sound Spam", method =() => AnoyyingMods.Rand()},
                new ButtonInfo { buttonText = "Globe Sound Spam", method =() => basicMods.PlayGlobeRPC()},
                new ButtonInfo { buttonText = "Shark Sound Spam", method =() => AnoyyingMods.Shark()},
                new ButtonInfo { buttonText = "Squirrel Sound Spam", method =() => AnoyyingMods.SSquirrel()},
                new ButtonInfo { buttonText = "FireFly Spam", method =() => AnoyyingMods.FireFlySpam()},
                new ButtonInfo { buttonText = "HeadSpin", method =() =>  trollMods.HeadSpin(), disableMethod =() => trollMods.nuhuhheadspin()},
                new ButtonInfo { buttonText = "Roll Monke", method =() => trollMods.RollMonke(), disableMethod =() => trollMods.NuhUhRollMonke()},
                new ButtonInfo { buttonText = "Weird Head", method =() => trollMods.WeirdHead(), disableMethod =() => trollMods.NuhUhWeirdHead()},
                new ButtonInfo { buttonText = "Head UpsideDown [<color=green>W/UND</color>]", method =() => trollMods.UpsideDownHead(), enabled = false,},
                new ButtonInfo { buttonText = "Grab Head [<color=green>W</color>/<color=red>DOES NOT FIX RIG</color]",method =() => trollMods.CursedGrabHead(), enabled = false,},
                new ButtonInfo { buttonText = "Grab Rig", method =() => basicMods.GrabRig(), disableMethod =() => basicMods.FixRig()},
                new ButtonInfo { buttonText = "Fix Rig", method =() => basicMods.FixRig()},
                new ButtonInfo { buttonText = "Wall Walk [<color=green>W?</color>]", method =() => basicMods.WeakWallWalk(), enabled = false,},
                new ButtonInfo { buttonText = "PunchMod", method =() => basicMods.PunchMod(), enabled = false,},
                new ButtonInfo { buttonText = "HandSpin1[<color=green>W</color>]", method =() => trollMods.HandSpin1(), disableMethod =() => trollMods.nuhuhHandSpin1(), toolTip = "Hands Go WEE", enabled = false,},
                new ButtonInfo { buttonText = "Freeze Rig Limbs [Credits to IIDK][<color=green>RG</color>]", method =() => trollMods.FreezeRigLimbs(), enabled = false,},
                new ButtonInfo { buttonText = "Freeze Rig Body [Credits to IIDK][<color=green>LG</color>]", method =() => trollMods.FreezeRigBody(), enabled = false},
                new ButtonInfo { buttonText = "Spaz Monke [<color=green>W?</color>]", method =() => trollMods.Spaz(), enabled = false,},
                new ButtonInfo { buttonText = "No Wind", method =() => basicMods.Nowind()},
                new ButtonInfo { buttonText = "Tracers", method =() => OpMods.InfectionTracers(), enabled = false},
                new ButtonInfo { buttonText = "Bone Esp", method =() => basicMods.InfectionBoneESP(), enabled = false,},
                new ButtonInfo { buttonText = "Jesus", method =() => basicMods.Jesus(), disableMethod =() => basicMods.FixWater()},
                new ButtonInfo { buttonText = "Reverse Jesus [<color=green>Forest</color>]", method =() => basicMods.GroundIsWater(), disableMethod =() => basicMods.FixInverseJesus()},
                new ButtonInfo { buttonText = "Fix Water", method =() => basicMods.FixWater()},
                new ButtonInfo { buttonText = "Fix Inverse Jesus", method =() => basicMods.FixInverseJesus()},
                new ButtonInfo { buttonText = "AntiReport", method =() => OpMods.AntiReportDisconnect(), enabled = true,},
                new ButtonInfo { buttonText = "Cum [<color=green>W/UND</color>]", method =() => Projectiles.Semen(), enabled = false },
                new ButtonInfo { buttonText = "Pee [<color=green>W/UND</color>]", method =() => Projectiles.Urine(), enabled = false },
                new ButtonInfo { buttonText = "Poo [<color=green>W/UND</color>]", method =() => Projectiles.Feces()},
                new ButtonInfo { buttonText = "Rainbow Snowballs [<color=green>W/UND</color>]", method =() => basicMods.RainbowSnowballs(), enabled = false, isTogglable = false },
                new ButtonInfo { buttonText = "WaterBend L [<color=green>RT/W/UND</color>]", method =() => basicMods.SplashL(), enabled = false },
                new ButtonInfo { buttonText = "WaterBend R [<color=green>RT/W/UND</color>]", method =() => basicMods.SplashR(), enabled = false },
                new ButtonInfo { buttonText = "Flush Rpcs", method =() => OpMods.flushmanually(), enableMethod =() => OpMods.RPCProtection(), isTogglable = false},
                new ButtonInfo { buttonText = "Disable Network Triggers", method =() => basicMods.DisableNetworkTriggers(), disableMethod =() => basicMods.EnableNetworkTriggers()},
                new ButtonInfo { buttonText = "Disable Quitbox", method =() => basicMods.DisableQuitBox(), disableMethod=() => basicMods.EnableQuitBox()},
                new ButtonInfo { buttonText = "Trap Stump [<color=red>M/ANTIBAN</color>]", method =() => OpMods.TrapStump(), isTogglable = false},
                new ButtonInfo { buttonText = "CheckPoint", method =() => basicMods.Checkpoint()},
                new ButtonInfo { buttonText = "No Name", method =() => basicMods.NoNamehehe(), isTogglable = false},
                new ButtonInfo { buttonText = "Become Frwosty (<color=purple>Owner</color>)", method =() => basicMods.becomeFrwosty(),isTogglable = false },
                new ButtonInfo { buttonText = "Become Slave (<color=green>Dev/Co-Owner</color>)", method =() => basicMods.BecomeSlave(), isTogglable = false },
                new ButtonInfo { buttonText = "Projectiles Spam [<color=green>W?/</color>]", method =() => Projectiles.ProjectileSpam()},
                new ButtonInfo { buttonText = "Projectile Delay", overlapText = "Projectile Delay [<color=purple>0.1</color>]", method =() => Projectiles.ProjectileDelay(), isTogglable = false, toolTip = "Gives the projectiles a delay before spawning another." },
                new ButtonInfo { buttonText = "Anti Ban", method =() => OpMods.AntiBan(), },
                new ButtonInfo { buttonText = "Set Master", method =() => OpMods.SetMaster(), isTogglable = false},
                new ButtonInfo { buttonText = "Crash All [May Kick u]", method =() => OpMods.Crashtest() },
               
                

            },

            new ButtonInfo[] { //Settings
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "Menu Settings", method =() => SettingsMods.MenuSettings(), isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Credits", method =() => SettingsMods.credits(), isTogglable = false},
            },

            new ButtonInfo[] {// menu settings
               new ButtonInfo { buttonText = "Return to Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = "Returns to the main settings page for the menu."},
               new ButtonInfo { buttonText = "Menu Theme", method =() => Global.menuthemes(), isTogglable = false },
                new ButtonInfo { buttonText = "Right Hand", enableMethod =() => SettingsMods.RightHand(), disableMethod =() => SettingsMods.LeftHand(), toolTip = "Puts the menu on your right hand."},
               new ButtonInfo { buttonText = "Notifications", enableMethod =() => SettingsMods.EnableNotifications(), disableMethod =() => SettingsMods.DisableNotifications(), enabled = !disableNotifications, toolTip = "Toggles the notifications."},
               new ButtonInfo { buttonText = "FPS Counter", enableMethod =() => SettingsMods.EnableFPSCounter(), disableMethod =() => SettingsMods.DisableFPSCounter(), enabled = fpsCounter, toolTip = "Toggles the FPS counter."},
               new ButtonInfo { buttonText = "Disconnect Button", enableMethod =() => SettingsMods.EnableDisconnectButton(), disableMethod =() => SettingsMods.DisableDisconnectButton(), enabled = disconnectButton, toolTip = "Toggles the disconnect button."},
               new ButtonInfo { buttonText = "Join Discord", method =() => Process.Start("https://discord.gg/EJzqyaSvgk")},
               new ButtonInfo { buttonText = "First Person Cam", method =() => basicMods.fpc(), disableMethod =() => basicMods.fpcoff()},
            },

            new ButtonInfo[] { // Credits

                new ButtonInfo { buttonText = "Back", method =() => SettingsMods.MenuSettings()},

                new ButtonInfo { buttonText = "iidk [<color=orange>TheGoldenTrophy</color>]", isTogglable = false },
                new ButtonInfo { buttonText = "<color=purple>Solar/Xen</color> [<color=purple>Developer</color>]", isTogglable = false},
                new ButtonInfo { buttonText = "<color=yellow>Slave</color> [<color=yellow>Developer</color>]", isTogglable =false },
                new ButtonInfo { buttonText = "<color=purple>Frwosty</color> [<color=purple>Menu Owner</color>]", isTogglable=false },
                new ButtonInfo { buttonText = "<color=red>Flaming Hamster</color> [<color=red>Helper/Developer</color>]"}

            },

            

            


            
        };









































        public static int[] bones = new int[] {
            4, 3, 5, 4, 19, 18, 20, 19, 3, 18, 21, 20, 22, 21, 25, 21, 29, 21, 31, 29, 27, 25, 24, 22, 6, 5, 7, 6, 10, 6, 14, 6, 16, 14, 12, 10, 9, 7
        };
        public static bool hasRemovedThisFrame = false;
        public static float projDebounce;

        // Token: 0x0400009A RID: 154
        public static float projDebounceType;
    }
}
