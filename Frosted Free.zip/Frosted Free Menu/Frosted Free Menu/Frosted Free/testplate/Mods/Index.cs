﻿using StupidTemplate.Classes;
using StupidTemplate.Menu;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class Index
    {
        public static ButtonInfo GetIndex(string buttonText)
        {
            System.Collections.IList list = Buttons.buttons;
            for (int i = 0; i < list.Count; i++)
            {
                ButtonInfo[] buttons = (ButtonInfo[])list[i];
                foreach (ButtonInfo button in buttons)
                {
                    if (button.buttonText == buttonText)
                    {
                        return button;
                    }
                }
            }

            return null;
        }
    }
}
