﻿using StupidTemplate.Menu;
using UnityEngine.UIElements;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate.Mods
{
    internal class Global
    {
        public static void ReturnHome()
        {
            buttonsType = 0;
        }

        public static void menuthemes()
        {
            int theme = 1;
            theme++;
            if(theme > 2)
            {
                theme = 1;
            }
            if (theme == 1) 
            {
                Settings.backgroundColor.isRainbow = false;
            }
            if (theme == 2)
            {
                Settings.backgroundColor.isRainbow = true;
            }
            
        }
        

        
    
        
    }
}
