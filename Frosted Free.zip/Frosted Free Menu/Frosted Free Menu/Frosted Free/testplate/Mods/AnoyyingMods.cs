﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class AnoyyingMods
    {
        //200
        //237
        //106

        public static void FireFlySpam()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0 && balll < Time.time)
            {
                balll = Time.time + 0.01f;
                GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", 0, new object[]
                {
                    106,
                    true,
                    999f
                });
                Mods.OpMods.flushmanually();
            }
        }
        public static void SSquirrel()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0 && balll < Time.time)
            {
                balll = Time.time + 0.01f;
                GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", 0, new object[]
                {
                    237,
                    true,
                    999f
                });
                Mods.OpMods.flushmanually();
            }
        }
        public static void Shark()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0 && balll < Time.time)
            {
                balll = Time.time + 0.01f;
                GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", 0, new object[]
                {
                    200,
                    true,
                    999f
                });
                Mods.OpMods.flushmanually();
            }
        }

        public static void Metal()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0 && balll < Time.time)
            {
                balll = Time.time + 0.01f;
                GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", 0, new object[]
                {
                    18,
                    true,
                    999f
                });
                Mods.OpMods.flushmanually();
            }
        }

        public static void Crystal()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0 && balll < Time.time)
            {
                balll = Time.time + 0.01f;
                GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", 0, new object[]
                {
                    20,
                    true,
                    999f
                });
                Mods.OpMods.flushmanually();
            }
        }

        public static void HugeCrystal()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0 && balll < Time.time)
            {
                balll = Time.time + 0.01f;
                GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", 0, new object[]
                {
                    213,
                    true,
                    999f
                });
                Mods.OpMods.flushmanually();
            }
        }

        public static void Ear()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0 && balll < Time.time)
            {
                balll = Time.time + 0.01f;
                GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", 0, new object[]
                {
                    215,
                    true,
                    999f
                });
                Mods.OpMods.flushmanually();
            }
        }

        public static void Rand()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0 && balll < Time.time)
            {
                balll = Time.time + 0.01f;
                int num = UnityEngine.Random.Range(0, 215);
                GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", 0, new object[]
                {
                    num,
                    true,
                    999f
                });
                Mods.OpMods.flushmanually();
            }
        }

        public static void AK()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0 && balll < Time.time)
            {
                balll = Time.time + 0.01f;
                GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", 0, new object[]
                {
                    203,
                    true,
                    999f
                });
                OpMods.flushmanually();
            }
        }
        public static float balll = 0f;
        public static void LoudTaps()
        {
            GorillaTagger.Instance.handTapVolume = 999f;
            stuiejrf2 = true;
        }

        public static void OFFLoudTaps()
        {
            if (stuiejrf2)
            {
                stuiejrf2 = false;
                GorillaTagger.Instance.handTapVolume = 0.1f;
            }
        }

        public static void SilentTaps()
        {
            GorillaTagger.Instance.handTapVolume = 0f;
            stuiejrf2 = true;
        }

        public static void OFFSilentTaps()
        {
            if (stuiejrf2)
            {
                stuiejrf2 = false;
                GorillaTagger.Instance.handTapVolume = 0.1f;
            }
        }

        public static void NoTapCooldown()
        {
            GorillaTagger.Instance.tapCoolDown = 0f;
            stuiejrf2 = true;
        }

        public static void TapCooldown()
        {
            if (stuiejrf2)
            {
                stuiejrf2 = false;
                GorillaTagger.Instance.tapCoolDown = 1f;
            }
        }
        private static bool stuiejrf2 = false;
    }
}
