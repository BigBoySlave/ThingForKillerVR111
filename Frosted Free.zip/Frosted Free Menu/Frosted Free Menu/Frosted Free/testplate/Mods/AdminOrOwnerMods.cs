﻿using dark.efijiPOIWikjek;
using ExitGames.Client.Photon;
using GorillaLocomotion.Gameplay;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using Sirenix.OdinInspector;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using Valve.VR;
using static MonoMod.Cil.RuntimeILReferenceBag.FastDelegateInvokers;
using Index = StupidTemplate.Mods.Index;
using RigManager = StupidTemplate.Classes.RigManager;

namespace StupidTemplate.Mods
{
    internal class AdminOrOwnerMods
    {
        
         public static void ProjectileSpam()
        {
            int projIndex = projmode;
            int trailIndex = trailmode;

            if (ControllerInputPoller.Instance.rightGrab)
            {
                
                string projectilename = fullProjectileNames[projIndex];

                
                string trailname = fullTrailNames[trailIndex];

                Vector3 startpos = GorillaTagger.Instance.rightHandTransform.position;
                Vector3 charvel = GorillaLocomotion.Player.Instance.currentVelocity;

                float randa = 255f;
                float randb = 255f;
                float randc = 255f;
                SysFireProjectile(projectilename, trailname, startpos, charvel, randa / 255f, randb / 255f, randc / 255f, GetIndex("Blue Team Projectiles").enabled, GetIndex("Orange Team Projectiles").enabled);
            }
         

    }
}
