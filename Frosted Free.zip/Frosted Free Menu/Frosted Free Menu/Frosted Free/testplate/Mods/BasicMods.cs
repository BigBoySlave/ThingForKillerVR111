﻿
using dark.efijiPOIWikjek;
using ExitGames.Client.Photon;
using GorillaLocomotion.Gameplay;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using Sirenix.OdinInspector;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using Valve.VR;
using static MonoMod.Cil.RuntimeILReferenceBag.FastDelegateInvokers;
using Index = StupidTemplate.Mods.Index;
using RigManager = StupidTemplate.Classes.RigManager;

namespace StupidTemplate.Menu
{
    internal class basicMods
    {

        /*
         * Strobe
Lazer Eyes
Update Rig
When you go invis there are dots where ur hands are
When you go ghost monke there are dots where ur hands are
Kill all (PaintBrawl)
Tag Aura
Untaggable
Tag All (hunt)
Tag Gun (hunt)
kill gun (paintbrawl) 
Low Gravity
No Gravity
High Gravity
Airstrike
Tp To Random
C4
Rig Gun
Grab Rig
Helicopter
Bees
SizeChanger
LookAtRandom
OrbitPlayerGun
FollowPlayerGun
CopyMovementGun
WalkOnWater (Solid Water)
Disable Water
FastSwim
FixWater
LongJump
FlickJump
Remove Decorations
Destroy Bug
Destroy Bat
Destroy BeachBall
Pop Balloons
Balloon Gun
Grab Balloons
Destroy Balloons
No Name
Name = Run
Name = Daisy09
Name = Statue
Name = Pbbv
Name = Behind You
Name = J3VU
Name = Echo
Become Run
Become Daisy09
Become Statue
Become Pbbv
Become J3VU
Vomit 


        GUN:

                    RaycastHit raycastHit;
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
                    {
                       pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                        UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        pointer.GetComponent<Renderer>().material.color = new Color32(0, 255, 0, 1);
                    }
                    pointer.transform.position = raycastHit.point;

        */





        public static void TpPlayerToU()
        {
            Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, out var Ray);
            RaycastHit raycastHit;
            if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
            {
                pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                pointer.GetComponent<Renderer>().material.color = new Color32(0, 255, 0, 1);
            }
            pointer.transform.position = raycastHit.point;
            if (OpMods.isCopying && OpMods.whoCopy != null)
            {


                GameObject l = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                UnityEngine.Object.Destroy(l.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(l.GetComponent<SphereCollider>());

                l.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                l.transform.position = GorillaTagger.Instance.leftHandTransform.position;

                GameObject r = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                UnityEngine.Object.Destroy(r.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(r.GetComponent<SphereCollider>());

                r.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                r.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                l.GetComponent<Renderer>().material.color = bgColorA;
                r.GetComponent<Renderer>().material.color = bgColorA;

                UnityEngine.Object.Destroy(l, Time.deltaTime);
                UnityEngine.Object.Destroy(r, Time.deltaTime);
            }
            if (rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
            {
                VRRig possibly = Ray.collider.GetComponentInParent<VRRig>();
                if (possibly && possibly != GorillaTagger.Instance.offlineVRRig)
                {

                    OpMods.isCopying = true;
                    OpMods.whoCopy = possibly;
                    GorillaTagger.Instance.offlineVRRig.enabled = false;

                    Vector3 HandPoopPosition = OpMods.whoCopy.rightHandTransform.position;
                    HandPoopPosition.y += 1f;

                    GorillaTagger.Instance.offlineVRRig.transform.position = HandPoopPosition;

                    GorillaTagger.Instance.myVRRig.transform.position = HandPoopPosition;

                    Vector3 startpos = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, -0.3f, 0f);
                    Vector3 charvel = Vector3.zero;

                    Mods.OpMods.BetaFireProjectile("SlingshotProjectile", startpos, charvel, new Color32(54, 33, 0, 255));
                }
            }
        }
            




        


        public static void RigGun()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {


                RaycastHit raycastHit;
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.color = new Color32(0, 255, 0, 1);
                }
                pointer.transform.position = raycastHit.point;
                if(ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f)
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position = pointer.transform.position;
                    RigShit.GetOwnVRRig().transform.position = pointer.transform.position;
                }
            }
        }
        public static void PoopOnSomeonesHandGun()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, out var Ray);
                RaycastHit raycastHit;
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.color = new Color32(0, 255, 0, 1);
                }
                pointer.transform.position = raycastHit.point;
                if (OpMods.isCopying && OpMods.whoCopy != null)
                {
                    

                    GameObject l = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(l.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(l.GetComponent<SphereCollider>());

                    l.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                    l.transform.position = GorillaTagger.Instance.leftHandTransform.position;

                    GameObject r = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(r.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(r.GetComponent<SphereCollider>());

                    r.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                    r.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                    l.GetComponent<Renderer>().material.color = bgColorA;
                    r.GetComponent<Renderer>().material.color = bgColorA;

                    UnityEngine.Object.Destroy(l, Time.deltaTime);
                    UnityEngine.Object.Destroy(r, Time.deltaTime);
                }
                if (rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
                {
                    VRRig possibly = Ray.collider.GetComponentInParent<VRRig>();
                    if (possibly && possibly != GorillaTagger.Instance.offlineVRRig)
                    {
                        
                        OpMods.isCopying = true;
                        OpMods.whoCopy = possibly;
                        GorillaTagger.Instance.offlineVRRig.enabled = false;

                        Vector3 HandPoopPosition = OpMods.whoCopy.rightHandTransform.position;
                        HandPoopPosition.y += 1f;

                        GorillaTagger.Instance.offlineVRRig.transform.position = HandPoopPosition;

                        GorillaTagger.Instance.myVRRig.transform.position = HandPoopPosition;

                        Vector3 startpos = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, -0.3f, 0f);
                        Vector3 charvel = Vector3.zero;

                        Mods.OpMods.BetaFireProjectile("SlingshotProjectile", startpos, charvel, new Color32(54, 33, 0, 255));
                    }
                }
            }
            else
            {
                if (OpMods.isCopying)
                {
                    OpMods.isCopying = false;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
        }

        public static void PoopOnSomeoneGun()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, out var Ray);
                RaycastHit raycastHit;
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.color = new Color32(0, 255, 0, 1);
                }
                pointer.transform.position = raycastHit.point;
                if (OpMods.isCopying && OpMods.whoCopy != null)
                {
                    

                    GameObject l = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(l.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(l.GetComponent<SphereCollider>());

                    l.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                    l.transform.position = GorillaTagger.Instance.leftHandTransform.position;

                    GameObject r = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(r.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(r.GetComponent<SphereCollider>());

                    r.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                    r.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                    l.GetComponent<Renderer>().material.color = bgColorA;
                    r.GetComponent<Renderer>().material.color = bgColorA;

                    UnityEngine.Object.Destroy(l, Time.deltaTime);
                    UnityEngine.Object.Destroy(r, Time.deltaTime);
                }
                if (rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
                {
                    VRRig possibly = Ray.collider.GetComponentInParent<VRRig>();
                    if (possibly && possibly != GorillaTagger.Instance.offlineVRRig)
                    {
                        OpMods.isCopying = true;
                        OpMods.whoCopy = possibly;
                        GorillaTagger.Instance.offlineVRRig.enabled = false;

                        Vector3 targetPosition = OpMods.whoCopy.transform.position;
                        targetPosition.y += 1f;

                        GorillaTagger.Instance.offlineVRRig.transform.position = targetPosition;

                        GorillaTagger.Instance.myVRRig.transform.position = targetPosition;

                        Vector3 startpos = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, -0.3f, 0f);
                        Vector3 charvel = Vector3.zero;

                        Mods.OpMods.BetaFireProjectile("SlingshotProjectile", startpos, charvel, new Color32(54, 33, 0, 255));
                    }
                }
            }
            else
            {
                if (OpMods.isCopying)
                {
                    OpMods.isCopying = false;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
        }

        public static void LetPeopleGrabYou()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, out var Ray);
                RaycastHit raycastHit;
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.color = new Color32(0, 255, 0, 1);
                }
                pointer.transform.position = raycastHit.point;
                if (OpMods.isCopying && OpMods.whoCopy != null)
                {
                    

                    GameObject l = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(l.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(l.GetComponent<SphereCollider>());

                    l.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                    l.transform.position = GorillaTagger.Instance.leftHandTransform.position;

                    GameObject r = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(r.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(r.GetComponent<SphereCollider>());

                    r.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                    r.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                    l.GetComponent<Renderer>().material.color = bgColorA;
                    r.GetComponent<Renderer>().material.color = bgColorA;

                    UnityEngine.Object.Destroy(l, Time.deltaTime);
                    UnityEngine.Object.Destroy(r, Time.deltaTime);
                }
                if (rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
                {
                    VRRig possibly = Ray.collider.GetComponentInParent<VRRig>();
                    if (possibly && possibly != GorillaTagger.Instance.offlineVRRig)
                    {
                        OpMods.isCopying = true;
                        OpMods.whoCopy = possibly;
                        GorillaTagger.Instance.offlineVRRig.enabled = false;

                        GorillaTagger.Instance.offlineVRRig.transform.position = OpMods.whoCopy.rightHandTransform.position;
                        GorillaTagger.Instance.myVRRig.transform.position = OpMods.whoCopy.rightHandTransform.position;
                    }
                }
            }
            else
            {
                if (OpMods.isCopying)
                {
                    OpMods.isCopying = false;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
        }

        public static void JoyStickRopes()
        {
            Vector2 joy = ControllerInputPoller.instance.rightControllerPrimary2DAxis;

            if (Mathf.Abs(joy.x) > 0.3 || Mathf.Abs(joy.y) > 0.3)
            {
                foreach (GorillaRopeSwing rope in GameObject.FindObjectsOfType(typeof(GorillaRopeSwing)))
                {
                    RopeSwingManager.instance.SendSetVelocity_RPC(rope.ropeId, 1, new Vector3(joy.x * 50f, joy.y * 50f, 0f), true);
                    OpMods.RPCProtection();
                }
            }
        }
        public static void TagBot()
        {
            bool rightSecondary = ControllerInputPoller.instance.rightControllerSecondaryButton;
            if (rightSecondary)
            {
                Main.GetIndex("Tag All Loop").enabled = false;
            }
            bool inRoom = PhotonNetwork.InRoom;
            if (inRoom)
            {
                bool flag = !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected");
                if (flag)
                {
                    bool flag2 = false;
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        bool flag3 = vrrig.mainSkin.material.name.Contains("fected");
                        if (flag3)
                        {
                            flag2 = true;
                            break;
                        }
                    }
                    bool flag4 = flag2;
                    if (flag4)
                    {
                        Main.GetIndex("Tag Self").method.Invoke();
                        Main.GetIndex("Tag All").enabled = false;
                    }
                }
                else
                {
                    bool flag5 = false;
                    foreach (VRRig vrrig2 in GorillaParent.instance.vrrigs)
                    {
                        bool flag6 = !vrrig2.mainSkin.material.name.Contains("fected");
                        if (flag6)
                        {
                            flag5 = true;
                            break;
                        }
                    }
                    bool flag7 = flag5;
                    if (flag7)
                    {
                        Main.GetIndex("Tag All").enabled = true;
                    }
                }
            }
        }

        public static void TagSelf()
        {
            /*if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") && Time.time > delaythinggg)
            {
                PhotonView.Get(GorillaGameManager.instance).RPC("ReportContactWithLavaRPC", RpcTarget.MasterClient, Array.Empty<object>());
                delaythinggg = Time.time + 0.5f;
            }*/
            foreach (GorillaTagManager gorillaTagManager in GameObject.FindObjectsOfType<GorillaTagManager>())
            {
                if (gorillaTagManager.currentInfected.Contains(PhotonNetwork.LocalPlayer))
                {
                     GorillaTagger.Instance.offlineVRRig.enabled = true;
                    Index.GetIndex("Tag Self").enabled = false;
                }
                else
                {
                    foreach (VRRig rig in GorillaParent.instance.vrrigs)
                    {
                        if (rig.mainSkin.material.name.Contains("fected"))
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = rig.rightHandTransform.position;
                            GorillaTagger.Instance.myVRRig.transform.position = rig.rightHandTransform.position;
                        }
                    }
                }
            }
        }




      
        public static void UntagSelf()
        {
            if (PhotonNetwork.LocalPlayer == PhotonNetwork.MasterClient)
            {
                foreach (GorillaTagManager tagman in GameObject.FindObjectsOfType<GorillaTagManager>())
                {
                    if (tagman.currentInfected.Contains(PhotonNetwork.LocalPlayer))
                    {
                        tagman.currentInfected.Remove(PhotonNetwork.LocalPlayer);
                    }
                }
            }
            else
            {
                
            }
        }

        public static void NoName()
        {
            
        }
        public static void FixRig ()
        {
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = 0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset.x = 0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset.z = 0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset.y = 0f;
            RigShit.GetOwnVRRig().head.trackingPositionOffset = GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset;
            RigShit.GetOwnVRRig().leftHand.trackingPositionOffset = GorillaTagger.Instance.offlineVRRig.leftHand.trackingPositionOffset;
            RigShit.GetOwnVRRig().rightHand.trackingPositionOffset = GorillaTagger.Instance.offlineVRRig.rightHand.trackingPositionOffset;
            RigShit.GetOwnVRRig().transform.position = GorillaTagger.Instance.offlineVRRig.headBodyOffset;
        }


        public static void GrabRig()
        {
            if (rightGrab)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                GorillaTagger.Instance.myVRRig.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                GameObject l = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                UnityEngine.Object.Destroy(l.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(l.GetComponent<SphereCollider>());

                l.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                l.transform.position = GorillaTagger.Instance.leftHandTransform.position;

                GameObject r = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                UnityEngine.Object.Destroy(r.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(r.GetComponent<SphereCollider>());

                r.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                r.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                l.GetComponent<Renderer>().material.color = bgColorA;
                r.GetComponent<Renderer>().material.color = bgColorA;

                UnityEngine.Object.Destroy(l, Time.deltaTime);
                UnityEngine.Object.Destroy(r, Time.deltaTime);
            }
        
        }

        public static void Speedboost()
        {
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 6f;
            GorillaLocomotion.Player.Instance.jumpMultiplier = 6.5f;
        }
        public static void Mosaboost()
        {
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 4f;
            GorillaLocomotion.Player.Instance.jumpMultiplier = 3.8f;
            
        }
        public static void ExtremeBoost()
        {
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 99f;
            GorillaLocomotion.Player.Instance.jumpMultiplier = 99f;
        }
        public static void FuckingInsaneBoost()
        {
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 999f;
            GorillaLocomotion.Player.Instance.jumpMultiplier = 999f;
        }
        public static void poopy()
        {
            if (rightGrab || Mouse.current.leftButton.isPressed)
            {
                Vector3 startpos = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, -0.3f, 0f);
                Vector3 charvel = Vector3.zero;

                OpMods.SysFireProjectile("SnowballProjectile", "none", startpos, charvel, 99f / 255f, 43f / 255f, 0f, false, false);
            }
        }


        


        public static void cum()
        {
            if (rightGrab || Mouse.current.leftButton.isPressed)
            {
                
                Vector3 startpos = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, -0.15f, 0f);
                Vector3 charvel = GorillaTagger.Instance.bodyCollider.transform.forward * 8.33f;

                OpMods.SysFireProjectile("SlingshotProjectile", "none", startpos, charvel, 255f, 255f, 255f, false, false);
            }
        }

        public static void pee()
        {
            if (rightGrab || Mouse.current.leftButton.isPressed)
            {
                Vector3 startpos = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, -0.15f, 0f);
                Vector3 charvel = GorillaTagger.Instance.bodyCollider.transform.forward * 8.33f;

                OpMods.SysFireProjectile("SlingshotProjectile", "none", startpos, charvel, 255f, 255f, 0f, false, false);
            }
        }

        public static bool shouldBePC = false;
        public static bool rightPrimary = false;
        public static bool rightSecondary = false;
        public static bool leftPrimary = false;
        public static bool leftSecondary = false;
        public static bool leftGrab = false;
        public static bool rightGrab = false;
        public static float leftTrigger = 0f;
        public static float rightTrigger = 0f;
        public static void MOTD()
        {
            GameObject.Find("motdtext").GetComponent<Text>().text = "Text";//MOTD title
            GameObject.Find("COC Text").GetComponent<Text>().text = "Text";//COC writing
            GameObject.Find("CodeOfConduct").GetComponent<Text>().text = "Text";//COC Title
            GameObject.Find("motd").GetComponent<Text>().text = "Text";//MOTD writing
            GameObject.Find("motdscreen").GetComponent<Renderer>().material.color = new Color32(186, 50, 213, 255);//MOTD colour
        }

        public static bool EverythingSlippery, EverythingGrippy;
        
        public static void EnableSlipperyHands()
        {
            EverythingSlippery = true;
        }

        public static void DisableSlipperyHands()
        {
            EverythingSlippery = false;
        }

        public static void EnableGrippyHands()
        {
            EverythingGrippy = true;
        }

        public static void DisableGrippyHands()
        {
            EverythingGrippy = false;
        }
        public static void EnableSlideControl()
        {
            
            GorillaLocomotion.Player.Instance.slideControl = 9999999999999999999999999999999f;
        }



        public static void EnableWeakSlideControl()
        {
            
            GorillaLocomotion.Player.Instance.slideControl = 999999999999999f;
        }

        public static void DisableSlideControl()
        {
            GorillaLocomotion.Player.Instance.slideControl = 9999999999999999999999999999999f;
        }

        public static void fpc()
        {
            fpcc = true;
            if (GameObject.Find("Third Person Camera") != null)
            {
                funn = GameObject.Find("Third Person Camera");
                funn.SetActive(false);
            }
            if (GameObject.Find("CameraTablet(Clone)") != null)
            {
                funn = GameObject.Find("CameraTablet(Clone)");
                funn.SetActive(false);
            }
        }
        public static GameObject funn;
        public static bool fpcc;
        public static void fpcoff()
        {
            fpcc = false;
            if (funn != null)
            {
                funn.SetActive(true);
                funn = null;
            }
        }

            public static void NoLilyPads()//Fixed By Frwosty?
        {
           if (ControllerInputPoller.instance.leftGrab)
           {
           GameObject.Find("Environment Objects/LocalObjects_Prefab/RotatingMap/SwampLevel/Art/Lilypad").SetActive(false);
           }
           else
           {
           GameObject.Find("Environment Objects/LocalObjects_Prefab/RotatingMap/SwampLevel/Art/Lilypad").SetActive(true);
           }
        }

        public static float balll = 0f;
        public static void PlayGlobeRPC()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0 && balll < Time.time)
            {
                balll = Time.time + 0.01f;
                GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", 0, new object[]
                {
                    129,
                    true,
                    999f
                });
                Mods.OpMods.flushmanually();
            }
        }

        
        public static void ChangeGanmeModeBattle()
        {
            int num = -1;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                {
                    vrrig.enabled = true; continue;
                }
            }
        }

        public static void ZeroGravity()
        {
            GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (9.81f / Time.deltaTime)), ForceMode.Acceleration);
        }

        public static void BarkFly()
        {
            GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (9.81f / Time.deltaTime)), ForceMode.Acceleration);
            var body = GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody;
            Vector2 joystickLeft = SteamVR_Actions.gorillaTag_LeftJoystick2DAxis.axis;
            float joystickRight = SteamVR_Actions.gorillaTag_RightJoystick2DAxis.axis.y;

            Vector3 actualJoystick = new Vector3(joystickLeft.x, joystickRight, joystickLeft.y);
            var Forward = GorillaLocomotion.Player.Instance.bodyCollider.transform.forward;
            Forward.y = 0;
            var Right = GorillaLocomotion.Player.Instance.bodyCollider.transform.right;
            Right.y = 0;
            var velocity = actualJoystick.x * Right + joystickRight * Vector3.up + actualJoystick.z * Forward;
            velocity *= GorillaLocomotion.Player.Instance.scale * 10f;
            body.velocity = Vector3.Lerp(body.velocity, velocity, 0.12875f);
        }

        private static List<GameObject> jumpRightObjects = new List<GameObject>();
        public static GameObject pointer;
        public static void PlatformGun()
        {
            if(ControllerInputPoller.instance.rightGrab)
            {
                RaycastHit raycastHit;
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.color = new Color32(176, 61, 225, 1);
                    if(ControllerInputPoller.instance.rightControllerIndexFloat > 0f)
                    {
                        GameObject jumpRightObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        jumpRightObject.transform.position = pointer.transform.position;
                        jumpRightObject.transform.localScale = scale;
                        jumpRightObject.GetComponent<Renderer>().material.color = Color.black;



                        jumpRightObjects.Add(jumpRightObject);
                    }
                }
            }
        }

        
        public static Camera TPC = null;
        public static int themeType = 1;
        public static Color bgColorA = new Color32(255, 128, 0, 128);
        public static Color bgColorB = new Color32(255, 102, 0, 128);
        public static GameObject CheckPoint = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        public static void Checkpoint()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                if (CheckPoint == null)
                {
                    CheckPoint = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(CheckPoint.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(CheckPoint.GetComponent<SphereCollider>());
                    CheckPoint.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                }
                CheckPoint.transform.position = GorillaTagger.Instance.rightHandTransform.position;
            }
            if (CheckPoint != null)
            {
                if (ControllerInputPoller.instance.rightControllerPrimaryButton)
                {
                    CheckPoint.GetComponent<Renderer>().material.color = new Color32(111,0,211,0) ;
                    GorillaTagger.Instance.rigidbody.transform.position = CheckPoint.transform.position;
                    GorillaTagger.Instance.rigidbody.velocity = Vector3.zero;
                }
                
            }
        }
        public static void DisableCheckpoint()
        {
            if (CheckPoint != null)
            {
                UnityEngine.Object.Destroy(CheckPoint);
                CheckPoint = null;
            }
        }

        public static float laggyRigDelay = 0f;
        public static bool idiotfixthingy = false;
        public static void LaggyRig()
        {
            if (Time.time > laggyRigDelay)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
                idiotfixthingy = true;
                laggyRigDelay = Time.time + 0.5f;
            }
            else
            {
                if (idiotfixthingy)
                {
                    idiotfixthingy = false;
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                }
            }
        }

        


        public static void NiggerTime()
        {
            BetterDayNightManager.instance.SetTimeOfDay(0);
        }

        public static void WiggerTime()
        {
            BetterDayNightManager.instance.SetTimeOfDay(1);
        }

        public static void TagOnJoin()
        {
            PlayerPrefs.SetString("tutorial", "false");
            Hashtable h = new Hashtable();
            h.Add("didTutorial", false);
            PhotonNetwork.LocalPlayer.SetCustomProperties(h, null, null);
            PlayerPrefs.Save();
        }

        public static void NoTagOnJoinMEOWW()
        {
            PlayerPrefs.SetString("tutorial", "true");
            Hashtable h = new Hashtable();
            h.Add("didTutorial", true);
            PhotonNetwork.LocalPlayer.SetCustomProperties(h, null, null);
            PlayerPrefs.Save();
        }

        public static float delaythinggg = 0f;
        
        public static void ChangeIdentity()
        {
            string randomName = "FROSTEDUSER";
            for (var i = 0; i < 4; i++)
            {
                randomName = randomName + UnityEngine.Random.Range(0, 9).ToString();
            }

            ChangeName(randomName);

            byte randA = (byte)UnityEngine.Random.Range(0, 255);
            byte randB = (byte)UnityEngine.Random.Range(0, 255);
            byte randC = (byte)UnityEngine.Random.Range(0, 255);
            ChangeColor(new Color32(randA, randB, randC, 255));
        }
        public static bool isUpdatingValues = false;
        public static float valueChangeDelay = 0f;
        public static bool changingName = false;
        public static bool changingColor = false;
        public static Color colorChange = Color.black;
        public static void ChangeColor(Color color)
        {
            if (PhotonNetwork.InRoom)
            {
                if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                {
                    PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0f, 1f));
                    PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0f, 1f));
                    PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0f, 1f));

                    //GorillaTagger.Instance.offlineVRRig.mainSkin.material.color = color;
                    GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                    PlayerPrefs.Save();

                    GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, new object[] { color.r, color.g, color.b, false });
                    OpMods.RPCProtection();
                }
                else
                {
                    isUpdatingValues = true;
                    valueChangeDelay = Time.time + 0.5f;
                    changingColor = true;
                    colorChange = color;
                }
            }
            else
            {
                PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0f, 1f));
                PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0f, 1f));
                PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0f, 1f));

                //GorillaTagger.Instance.offlineVRRig.mainSkin.material.color = color;
                GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                PlayerPrefs.Save();

                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, new object[] { color.r, color.g, color.b, false });
                OpMods.RPCProtection();
            }
        }
        public static string nameChange = "";
        public static void ChangeName(string PlayerName)
        {
            try
            {
                if (PhotonNetwork.InRoom)
                {
                    if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                    {
                        GorillaComputer.instance.currentName = PlayerName;
                        PhotonNetwork.LocalPlayer.NickName = PlayerName;
                        GorillaComputer.instance.offlineVRRigNametagText.text = PlayerName;
                        GorillaComputer.instance.savedName = PlayerName;
                        PlayerPrefs.SetString("playerName", PlayerName);
                        PlayerPrefs.Save();

                        ChangeColor(GorillaTagger.Instance.offlineVRRig.playerColor);
                    }
                    else
                    {
                        isUpdatingValues = true;
                        valueChangeDelay = Time.time + 0.5f;
                        changingName = true;
                        nameChange = PlayerName;
                    }
                }
                else
                {
                    GorillaComputer.instance.currentName = PlayerName;
                    PhotonNetwork.LocalPlayer.NickName = PlayerName;
                    GorillaComputer.instance.offlineVRRigNametagText.text = PlayerName;
                    GorillaComputer.instance.savedName = PlayerName;
                    PlayerPrefs.SetString("playerName", PlayerName);
                    PlayerPrefs.Save();

                    ChangeColor(GorillaTagger.Instance.offlineVRRig.playerColor);
                }
            }
            catch (Exception exception)
            {
               
            }
        }
        public static void ForceLagGame()
        {
            foreach (GameObject g in UnityEngine.Object.FindObjectsByType<GameObject>(0)) { }
        }

        public static void DisableNetworkTriggers()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
        }

        public static void EnableNetworkTriggers()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
        }

        public static void DisableQuitBox()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").SetActive(false);
        }

        public static void EnableQuitBox()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").SetActive(true);
        }

        //GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 25;
       // GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;

       public static void KeyMovement()
        {
            if (Input.GetKeyUp(KeyCode.W))
            {
                GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 25;
            }
            if (Input.GetKeyUp(KeyCode.D))
            {
                GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.right * Time.deltaTime * 25;
            }
        }
        
        public static void NightTime()
        {
            BetterDayNightManager.instance.SetTimeOfDay(0);
        }

        public static void DayTime()
        {
            BetterDayNightManager.instance.SetTimeOfDay(1);
        }

        public static Vector3[] lastLeft = new Vector3[]
        {
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero
        };

        public static Vector3[] lastRight = new Vector3[]
        {
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero,
            Vector3.zero
        };
        public static void PunchMod()
        {
            int num = -1;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                {
                    num++;
                    Vector3 position = vrrig.rightHandTransform.position;
                    Vector3 position2 = GorillaTagger.Instance.offlineVRRig.head.rigTarget.position;
                    if ((double)Vector3.Distance(position, position2) < 0.25)
                    {
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += Vector3.Normalize(vrrig.rightHandTransform.position - lastRight[num]) * 10f;
                    }
                    lastRight[num] = vrrig.rightHandTransform.position;
                    if ((double)Vector3.Distance(vrrig.leftHandTransform.position, position2) < 0.25)
                    {
                        GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity += Vector3.Normalize(vrrig.rightHandTransform.position - lastLeft[num]) * 10f;
                    }
                    lastLeft[num] = vrrig.leftHandTransform.position;
                }
            }
        }

        public static void WeakWallWalk()
        {
            if ((GorillaLocomotion.Player.Instance.wasLeftHandTouching || GorillaLocomotion.Player.Instance.wasRightHandTouching) && ControllerInputPoller.instance.rightGrab)
            {
                FieldInfo fieldInfo = typeof(GorillaLocomotion.Player).GetField("lastHitInfoHand", BindingFlags.NonPublic | BindingFlags.Instance);
                RaycastHit ray = (RaycastHit)fieldInfo.GetValue(GorillaLocomotion.Player.Instance);
                walkPos = ray.point;
                walkNormal = ray.normal;
            }
        }
        public static Vector3 walkPos;
        public static Vector3 walkNormal;

        public static void Nowind()
        {
            bool flag = GorillaLocomotion.Player.Instance != null;
            if (flag)
            {
                bool flag2 = GorillaGameManager.instance != null;
                if (flag2)
                {
                    GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/Environment/Forest_ForceVolumes").SetActive(false);
                    GameObject.Find("Environment Objects/LocalObjects_Prefab/Basement/DungeonRoomAnchor/DungeonBasement/BasementMouseHoleWindPrefab").SetActive(false);
                    GameObject.Find("Environment Objects/LocalObjects_Prefab/Basement/DungeonRoomAnchor/DungeonBasement/BasementMouseHoleWindPrefab (1)").SetActive(false);
                    GameObject.Find("Environment Objects/LocalObjects_Prefab/Basement/DungeonRoomAnchor/DungeonBasement/BasementMouseHoleWindPrefab (2)").SetActive(false);
                    GameObject.Find("Environment Objects/LocalObjects_Prefab/Canyon/Canyon/Canyon_ForceVolumes").SetActive(false);
                    GameObject.Find("Environment Objects/LocalObjects_Prefab/Beach/ForceVolumesOcean_Combo_V2").SetActive(false);
                    GameObject.Find("Environment Objects/LocalObjects_Prefab/skyjungle/Force Volumes").SetActive(false);
                }
            }
        }

        public static void AdminBadge()
        {
            GorillaTagger.Instance.offlineVRRig.concatStringOfCosmeticsAllowed.Contains("AdministratorBadge");
        }

        public static void Stick()
        {
            GorillaTagger.Instance.offlineVRRig.concatStringOfCosmeticsAllowed.Contains("MODSTICK");
        }

        public static void Noclipwplats()
        {
            PlatformsThing(false,false);
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0)
            {
                MeshCollider[] array = Resources.FindObjectsOfTypeAll<MeshCollider>();
                foreach (MeshCollider meshCollider in array)
                {
                    meshCollider.enabled = false;
                }
            }
            else
            {
                MeshCollider[] array = Resources.FindObjectsOfTypeAll<MeshCollider>();
                foreach (MeshCollider meshCollider in array)
                {
                    meshCollider.enabled = true;
                }
            }
        }

        public static void SplashL()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0f)
            {
                GorillaTagger.Instance.myVRRig.RPC("PlaySplashEffect", 0, new object[]
                {
                    GorillaTagger.Instance.leftHandTransform.position,
                    GorillaTagger.Instance.leftHandTransform.rotation,
                    4f,
                    100f,
                    true,
                    false
                });
            }
            OpMods.RPCProtection();
        }

        public static void BugGun()
        {
            if (rightGrab || Mouse.current.rightButton.isPressed)
            {
                Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, out var Ray);                             
                RaycastHit raycastHit;
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.color = new Color32(0, 255, 0, 1);
                }
                pointer.transform.position = raycastHit.point;
                if (rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
                {
                    GameObject.Find("Floating Bug Holdable").transform.position = pointer.transform.position + new Vector3(0f, 1f, 0f);
                }
            }
        }

        public static void BatGun()
        {
           if(rightGrab)
            {
                Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, out var Ray);
                RaycastHit raycastHit;
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.color = new Color32(0, 255, 0, 1);
                }
                pointer.transform.position = raycastHit.point;
                if(rightTrigger < 0.5f)
                {
                    GameObject.Find("Cave Bat Holdable").transform.position = pointer.transform.position;

                }
            }
        }

        public static void BeachBallGun()
        {
            if (rightGrab || Mouse.current.rightButton.isPressed)
            {
                Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.forward, out var Ray);
                if (shouldBePC)
                {
                    Ray ray = TPC.ScreenPointToRay(Mouse.current.position.ReadValue());
                    Physics.Raycast(ray, out Ray, 100);
                }

                RaycastHit raycastHit;
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                    UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                    pointer.GetComponent<Renderer>().material.color = new Color32(0, 255, 0, 1);
                }
                pointer.transform.position = raycastHit.point;
                if (rightTrigger > 0.5f || Mouse.current.leftButton.isPressed)
                {
                    GameObject.Find("BeachBall").transform.position = pointer.transform.position;
                }
            }
        }

        public static void GrabBug()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                GameObject.Find("Floating Bug Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
            }
        }

        public static void GrabBat()
        {
            if (ControllerInputPoller.instance.leftGrab)
            {
                GameObject.Find("Cave Bat Holdable").transform.position = GorillaTagger.Instance.leftHandTransform.position;
            }
        }

        public static void GrabBeachBall()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                GameObject.Find("BeachBall").transform.position = GorillaTagger.Instance.rightHandTransform.position;
            }
        }

        public static void DestroyBug()
        {
            GameObject.Find("Floating Bug Holdable").transform.position = new Vector3(99999f, 99999f, 99999f);
        }

        public static void DestroyBat()
        {
            GameObject.Find("Cave Bat Holdable").transform.position = new Vector3(99999f, 99999f, 99999f);
        }

        public static void DestroyBeachBall()
        {
            GameObject.Find("BeachBall").transform.position = new Vector3(99999f, 99999f, 99999f);
        }

       

       

        public static void SplashR()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0f)
            {
                GorillaTagger.Instance.myVRRig.RPC("PlaySplashEffect", 0, new object[]
                {

                    GorillaTagger.Instance.rightHandTransform.position,
                    GorillaTagger.Instance.rightHandTransform.rotation,
                    4f,
                    100f,
                    true,
                    false,

                });
            }
            OpMods.RPCProtection();
        }

        public static void UpsideUpHead()
        {
            RigShit.GetOwnVRRig().head.trackingRotationOffset.y = 0f;
        }
        public static void Semen()
        {
            bool flag = ControllerInputPoller.instance.rightGrab;
            if (flag)
            {
                Vector3 position = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, -0.15f, 0f);
                Vector3 velocity = GorillaTagger.Instance.bodyCollider.transform.forward * 8.33f;
                
                Mods.OpMods.BetaFireProjectile("SlingshotProjectile", position, velocity, new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue));
            }
        }

        public static void Poop()
        {
            if (rightGrab || Mouse.current.leftButton.isPressed)
            {
                Vector3 startpos = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, -0.3f, 0f);
                Vector3 charvel = Vector3.zero;

                Mods.OpMods.BetaFireProjectile("SlingshotProjectile", startpos, charvel, new Color32(54, 33, 0, 255));
            }
        }

        public static void Urine()
        {
            if (ControllerInputPoller.instance.rightGrab || Mouse.current.leftButton.isPressed)
            {
                Vector3 startpos = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, -0.15f, 0f);
                Vector3 charvel = GorillaTagger.Instance.bodyCollider.transform.forward * 8.33f;

                Mods.OpMods.BetaFireProjectile("SlingshotProjectile", startpos, charvel, new Color32(255, 255, 0, 255));
            }
        }

        public static void GroundIsWater()
        {
            GameObject pool = GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/Terrain/pitgeo/pit ground");
            Transform transformpool = pool.transform;
            for (int i = 0; i < transformpool.childCount; i++)
            {
                GameObject v = transformpool.GetChild(i).gameObject;
                v.layer = LayerMask.NameToLayer("Water");
            }
        }
        public static void FixWater()
        {
            GameObject pool = GameObject.Find("Environment Objects/LocalObjects_Prefab/Beach/B_WaterVolumes");
            Transform transformpool = pool.transform;
            for (int i = 0; i < transformpool.childCount; i++)
            {
                GameObject v = transformpool.GetChild(i).gameObject;
                v.layer = LayerMask.NameToLayer("Water");
            }
        }


        public static void SetMasterGun()
        {

        }

        public static void FixInverseJesus()
        {
            GameObject pool = GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/Terrain/pitgeo/pit ground");
            Transform transformpool = pool.transform;
            for (int i = 0; i < transformpool.childCount; i++)
            {
                GameObject v = transformpool.GetChild(i).gameObject;
                v.layer = LayerMask.NameToLayer("Default");
            }
        }

        public static void Jesus()
        {
            GameObject pool = GameObject.Find("Environment Objects/LocalObjects_Prefab/Beach/B_WaterVolumes");
            Transform transformpool = pool.transform;
            for (int i = 0; i < transformpool.childCount; i++)
            {
                GameObject v = transformpool.GetChild(i).gameObject;
                v.layer = LayerMask.NameToLayer("Default");
            }
        }

        public int wadawd = 0;
        public static void SizeChangeeer()
        {
            
        }

        public static void FastSwim()
        {
            if (GorillaLocomotion.Player.Instance.InWater)
            {
                GorillaLocomotion.Player.Instance.gameObject.GetComponent<Rigidbody>().velocity *= 1.069f;
            }
        }

        public static void SuperFastSwim()
        {
            if (GorillaLocomotion.Player.Instance.InWater)
            {
                GorillaLocomotion.Player.Instance.gameObject.GetComponent<Rigidbody>().velocity *= 999f;
            }
        }
        public static void RainbowSnowballs()
        {
            foreach (SnowballThrowable snowballThrowable in UnityEngine.Object.FindObjectsOfType<SnowballThrowable>())
            {
                bool flag = !snowballThrowable.randomizeColor;
                if (flag)
                {
                    snowballThrowable.randomizeColor = true;
                }
            }
        }
        public static void InfectionBoneESP()
        {
            bool isInfectedPlayers = false;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig.mainSkin.material.name.Contains("fected"))
                {
                    isInfectedPlayers = true;
                    break;
                }
            }
            if (isInfectedPlayers)
            {
                if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        UnityEngine.Color thecolor = new Color32(255, 111, 0, 255);
                        if (vrrig.mainSkin.material.name.Contains("fected") && vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            LineRenderer liner = vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                            liner.startWidth = 0.025f;
                            liner.endWidth = 0.025f;

                            liner.startColor = thecolor;
                            liner.endColor = thecolor;

                            liner.material.shader = Shader.Find("GUI/Text Shader");

                            liner.SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
                            liner.SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));

                            UnityEngine.Object.Destroy(liner, Time.deltaTime);
                            for (int i = 0; i < Buttons.bones.Count<int>(); i += 2)
                            {
                                liner = vrrig.mainSkin.bones[Buttons.bones[i]].gameObject.AddComponent<LineRenderer>();

                                liner.startWidth = 0.025f;
                                liner.endWidth = 0.025f;

                                liner.startColor = thecolor;
                                liner.endColor = thecolor;

                                liner.material.shader = Shader.Find("GUI/Text Shader");

                                liner.SetPosition(0, vrrig.mainSkin.bones[Buttons.bones[i]].position);
                                liner.SetPosition(1, vrrig.mainSkin.bones[Buttons.bones[i + 1]].position);

                                UnityEngine.Object.Destroy(liner, Time.deltaTime);
                            }
                        }
                    }
                }
                else
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        UnityEngine.Color thecolor = vrrig.playerColor;
                        if (!vrrig.mainSkin.material.name.Contains("fected") && vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            LineRenderer liner = vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                            liner.startWidth = 0.025f;
                            liner.endWidth = 0.025f;

                            liner.startColor = thecolor;
                            liner.endColor = thecolor;

                            liner.material.shader = Shader.Find("GUI/Text Shader");

                            liner.SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
                            liner.SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));

                            UnityEngine.Object.Destroy(liner, Time.deltaTime);
                            for (int i = 0; i < Buttons.bones.Count<int>(); i += 2)
                            {
                                liner = vrrig.mainSkin.bones[Buttons.bones[i]].gameObject.AddComponent<LineRenderer>();

                                liner.startWidth = 0.025f;
                                liner.endWidth = 0.025f;

                                liner.startColor = thecolor;
                                liner.endColor = thecolor;

                                liner.material.shader = Shader.Find("GUI/Text Shader");

                                liner.SetPosition(0, vrrig.mainSkin.bones[Buttons.bones[i]].position);
                                liner.SetPosition(1, vrrig.mainSkin.bones[Buttons.bones[i + 1]].position);

                                UnityEngine.Object.Destroy(liner, Time.deltaTime);
                            }
                        }
                    }
                }
            }
            else
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    UnityEngine.Color thecolor = vrrig.playerColor;
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        LineRenderer liner = vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                        liner.startWidth = 0.025f;
                        liner.endWidth = 0.025f;

                        liner.startColor = thecolor;
                        liner.endColor = thecolor;

                        liner.material.shader = Shader.Find("GUI/Text Shader");

                        liner.SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
                        liner.SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));

                        UnityEngine.Object.Destroy(liner, Time.deltaTime);
                        for (int i = 0; i < Buttons.bones.Count<int>(); i += 2)
                        {
                            liner = vrrig.mainSkin.bones[Buttons.bones[i]].gameObject.AddComponent<LineRenderer>();

                            liner.startWidth = 0.025f;
                            liner.endWidth = 0.025f;

                            liner.startColor = thecolor;
                            liner.endColor = thecolor;

                            liner.material.shader = Shader.Find("GUI/Text Shader");

                            liner.SetPosition(0, vrrig.mainSkin.bones[Buttons.bones[i]].position);
                            liner.SetPosition(1, vrrig.mainSkin.bones[Buttons.bones[i + 1]].position);

                            UnityEngine.Object.Destroy(liner, Time.deltaTime);
                        }
                    }
                }
            }
        }
        public static void LegitArms()
        {
            GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1.15f, 1.15f, 1.15f);
        }

        public static void ResetArms()
        {
            GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1f, 1f, 1f);
        }
        public static void LongArms()
        {
            GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);

        }

        public static void Noclip()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0)
            {
                MeshCollider[] array = Resources.FindObjectsOfTypeAll<MeshCollider>();
                foreach (MeshCollider meshCollider in array)
                {
                    meshCollider.enabled = false;
                }
            }
            else
            {
                MeshCollider[] array = Resources.FindObjectsOfTypeAll<MeshCollider>();
                foreach (MeshCollider meshCollider in array)
                {
                    meshCollider.enabled = true;
                }
            }
        }

        public static void GhostCam()
        {
            bool RightControllerSecondaryButton = ControllerInputPoller.instance.rightControllerSecondaryButton;
            if (RightControllerSecondaryButton)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
                
            }
        }



        public static void InvisMonke()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(-345, -345, -345);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;               
            }
        }

        public static void ChangeNmaetoEcho()
        {
            ChangeName("Echo");
        }

        public static void becomeFrwosty()
        {
            ChangeName("Frwosty");
            ChangeColor(new Color32(196, 32, 214, 255));
        }
        public static bool rightHand = false;
        public static void TagAllHunt()
        {
            GorillaHuntManager sillyComputer = GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>();
            Photon.Realtime.Player target = sillyComputer.GetTargetOf(PhotonNetwork.LocalPlayer);
            if (!GorillaLocomotion.Player.Instance.disableMovement)
            {
                VRRig vrrig = RigManager.GetVRRigFromPlayer(target);
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position;
                GorillaTagger.Instance.myVRRig.transform.position = vrrig.transform.position;
                if (rightHand == true) { GorillaLocomotion.Player.Instance.rightControllerTransform.position = vrrig.transform.position; } else { GorillaLocomotion.Player.Instance.leftControllerTransform.position = vrrig.transform.position; }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
                Index.GetIndex("Tag All (Hunt)").enabled = false;
            }
        }

        public static void CreatePublic()
        {
            Hashtable customRoomProperties;
            /*if (PhotonNetworkController.Instance.currentJoinTrigger.gameModeName != "city" && PhotonNetworkController.Instance.currentJoinTrigger.gameModeName != "basement")
            {*/
            customRoomProperties = new Hashtable
            {
                {
                    "gameMode",
                    PhotonNetworkController.Instance.currentJoinTrigger.gameModeName + GorillaComputer.instance.currentQueue + GorillaComputer.instance.currentGameMode.Value
                }
            };
            /*}
            else
            {
                customRoomProperties = new Hashtable
                {
                    {
                        "gameMode",
                        PhotonNetworkController.Instance.currentJoinTrigger.gameModeName + GorillaComputer.instance.currentQueue + "INFECTION"
                    }
                };
            }*/
            Photon.Realtime.RoomOptions roomOptions = new Photon.Realtime.RoomOptions();
            roomOptions.IsVisible = true;
            roomOptions.IsOpen = true;
            roomOptions.MaxPlayers = PhotonNetworkController.Instance.GetRoomSize(PhotonNetworkController.Instance.currentJoinTrigger.gameModeName);
            roomOptions.CustomRoomProperties = customRoomProperties;
            roomOptions.PublishUserId = true;
            roomOptions.CustomRoomPropertiesForLobby = new string[]
            {
                "gameMode"
            };
            PhotonNetwork.CreateRoom(RandomRoomName(), roomOptions, null, null);
        }



        public static string RandomRoomName()
        {
            string text = "";
            for (int i = 0; i < 4; i++)
            {
                text += NetworkSystem.roomCharacters.Substring(UnityEngine.Random.Range(0, NetworkSystem.roomCharacters.Length), 1);
            }
            if (GorillaComputer.instance.CheckAutoBanListForName(text))
            {
                return text;
            }
            return RandomRoomName();
        }
        public static void TagAll()
        {
            if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
            {
               Index.GetIndex("Tag Self").enabled = true;
               Index.GetIndex("Tag All").enabled = false;
            }
            else
            {
                bool isInfectedPlayers = false;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (!vrrig.mainSkin.material.name.Contains("fected"))
                    {
                        isInfectedPlayers = true;
                        break;
                    }
                }
                if (isInfectedPlayers == true)
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (!vrrig.mainSkin.material.name.Contains("fected"))
                        {
                            if (GorillaTagger.Instance.offlineVRRig.enabled == true)
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position;
                            GorillaTagger.Instance.myVRRig.transform.position = vrrig.transform.position;

                            Vector3 they = vrrig.transform.position;
                            Vector3 notthem = GorillaTagger.Instance.offlineVRRig.head.rigTarget.position;
                            float distance = Vector3.Distance(they, notthem);

                            if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") && !vrrig.mainSkin.material.name.Contains("fected") && distance < 1.667)
                            {
                                if (rightHand == true) { GorillaLocomotion.Player.Instance.rightControllerTransform.position = they; } else { GorillaLocomotion.Player.Instance.leftControllerTransform.position = they; }
                            }
                        }
                    }
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                    Index.GetIndex("Tag All").enabled = false;
                }
            }
        }
        public static void NoNamehehe()
        {
            ChangeName("_____");
        }
        public static void BecomeSlave()
        {
            ChangeName("Slave");
            ChangeColor(new Color32(223, 229, 50, 255));
        }
        
        public static void FastFly()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 40;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }

        public static void TriggerFly()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0)
            {
                GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 25;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }

        public static void SlowFly()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 8;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }

        public static void Fly()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 25;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }

        public static void Discnt()
        {
            PhotonNetwork.Disconnect();
        }

        public static void JoinRandom()
        {
            PhotonNetwork.JoinRandomRoom();
        }

        public static void Quit()
        {
            
            Application.Quit();
        }

        public static void PrimaryDiscnt()
        {
            if (ControllerInputPoller.instance.leftControllerPrimaryButton == true)
            {
                PhotonNetwork.Disconnect();
            }
        }

        public static void InvisPlats()
        {
            PlatformsThing(true, false);
        }

        public static void StickyPlats()
        {
            PlatformsThing(false, true);
        }

        public static void Plats()
        {
            PlatformsThing(false, false);
        }

        private static void PlatformsThing(bool invis, bool sticky)
        {
            colorKeysPlatformMonke[0].color = new Color32(145, 109, 191, 0);
            colorKeysPlatformMonke[0].time = 0f;
            colorKeysPlatformMonke[1].color = Color.black;
            colorKeysPlatformMonke[1].time = 0.3f;
            colorKeysPlatformMonke[2].color = new Color32(145, 109, 191, 0);
            colorKeysPlatformMonke[2].time = 0.6f;
            colorKeysPlatformMonke[3].color = Color.black;
            colorKeysPlatformMonke[3].time = 1f;
            bool inputr;
            bool inputl;
            inputr = ControllerInputPoller.instance.rightGrab;
            inputl = ControllerInputPoller.instance.leftGrab;
            if (inputr)
            {
                if (!once_right && jump_right_local == null)
                {
                    if (sticky)
                    {
                        jump_right_local = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    }
                    else
                    {
                        jump_right_local = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    }
                    jump_right_local.GetComponent<Renderer>().material.SetColor("_Color", Color.black);
                    if (invis)
                    {
                        UnityEngine.Object.Destroy(jump_right_local.GetComponent<Renderer>());
                    }
                    jump_right_local.transform.localScale = scale;
                    jump_right_local.transform.position = new Vector3(0f, -0.0100f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                    jump_right_local.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                    object[] eventContent = new object[2]
                    {
                    new Vector3(0f, -0.0100f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                    GorillaLocomotion.Player.Instance.rightControllerTransform.rotation
                    };
                    RaiseEventOptions raiseEventOptions = new RaiseEventOptions
                    {
                        Receivers = ReceiverGroup.Others
                    };
                    PhotonNetwork.RaiseEvent(70, eventContent, raiseEventOptions, SendOptions.SendReliable);
                    once_right = true;
                    once_right_false = false;
                    ShibaGTTemplate.Utilities.ColorChanger colorChanger = jump_right_local.AddComponent<ShibaGTTemplate.Utilities.ColorChanger>();
                    Gradient gradient = new Gradient();
                    gradient.colorKeys = colorKeysPlatformMonke;
                    colorChanger.colors = gradient;
                    colorChanger.Start();
                }
            }
            else if (!once_right_false && jump_right_local != null)
            {
                UnityEngine.Object.Destroy(jump_right_local);
                jump_right_local = null;
                once_right = false;
                once_right_false = true;
                RaiseEventOptions raiseEventOptions2 = new RaiseEventOptions
                {
                    Receivers = ReceiverGroup.Others
                };
                PhotonNetwork.RaiseEvent(72, null, raiseEventOptions2, SendOptions.SendReliable);
            }
            if (inputl)
            {
                if (!once_left && jump_left_local == null)
                {
                    if (sticky)
                    {
                        jump_left_local = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    }
                    else
                    {
                        jump_left_local = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    }
                    jump_left_local.GetComponent<Renderer>().material.SetColor("_Color", Color.black);
                    if (invis)
                    {
                        UnityEngine.Object.Destroy(jump_left_local.GetComponent<Renderer>());
                    }
                    jump_left_local.transform.localScale = scale;
                    jump_left_local.transform.position = new Vector3(0f, -0.0100f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                    jump_left_local.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                    object[] eventContent2 = new object[2]
                    {
                    new Vector3(0f, -0.0100f, 0f) + GorillaLocomotion.Player.Instance.leftControllerTransform.position,
                    GorillaLocomotion.Player.Instance.leftControllerTransform.rotation
                    };
                    RaiseEventOptions raiseEventOptions3 = new RaiseEventOptions
                    {
                        Receivers = ReceiverGroup.Others
                    };
                    PhotonNetwork.RaiseEvent(69, eventContent2, raiseEventOptions3, SendOptions.SendReliable);
                    once_left = true;
                    once_left_false = false;
                    ShibaGTTemplate.Utilities.ColorChanger colorChanger2 = jump_left_local.AddComponent<ShibaGTTemplate.Utilities.ColorChanger>();
                    Gradient gradient2 = new Gradient();
                    gradient2.colorKeys = colorKeysPlatformMonke;
                    colorChanger2.colors = gradient2;
                    colorChanger2.Start();
                }
            }
            else if (!once_left_false && jump_left_local != null)
            {
                UnityEngine.Object.Destroy(jump_left_local);
                jump_left_local = null;
                once_left = false;
                once_left_false = true;
                RaiseEventOptions raiseEventOptions4 = new RaiseEventOptions
                {
                    Receivers = ReceiverGroup.Others
                };
                PhotonNetwork.RaiseEvent(71, null, raiseEventOptions4, SendOptions.SendReliable);
            }
            if (!PhotonNetwork.InRoom)
            {
                for (int i = 0; i < jump_right_network.Length; i++)
                {
                    UnityEngine.Object.Destroy(jump_right_network[i]);
                }
                for (int j = 0; j < jump_left_network.Length; j++)
                {
                    UnityEngine.Object.Destroy(jump_left_network[j]);
                }
            }
        }

        

        private static Vector3 scale = new Vector3(0.0125f, 0.28f, 0.3825f);

        private static bool once_left;

        private static bool once_right;

        private static bool once_left_false;

        private static bool once_right_false;

        private static bool once_networking;

        private static GameObject[] jump_left_network = new GameObject[9999];

        private static GameObject[] jump_right_network = new GameObject[9999];

        private static GameObject jump_left_local = null;

        private static GameObject jump_right_local = null;

        private static GradientColorKey[] colorKeysPlatformMonke = new GradientColorKey[4];


    }

}

