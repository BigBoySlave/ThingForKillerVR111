﻿
using dark.efijiPOIWikjek;
using GorillaLocomotion;
using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;


namespace StupidTemplate.Mods
{


    internal class trollMods
    {


        public static void moes()
        {
            GameObject.Find("motdtext").GetComponent<Text>().text = "Text";//MOTD title
            GameObject.Find("COC Text").GetComponent<Text>().text = "Text";//COC writing
            GameObject.Find("CodeOfConduct").GetComponent<Text>().text = "Text";//COC Title
            GameObject.Find("motd").GetComponent<Text>().text = "Text";//MOTD writing
            GameObject.Find("motdscreen").GetComponent<Renderer>().material.color = new Color32(186, 50 ,213, 255);//MOTD colour
        }

        public static void longarms()
        {
            
        }

        public static void FreezeRigBody()
        {
            if (ControllerInputPoller.instance.leftGrab)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;

                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;

                GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation = GorillaTagger.Instance.headCollider.transform.rotation;

                GameObject l = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                UnityEngine.Object.Destroy(l.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(l.GetComponent<SphereCollider>());

                l.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                l.transform.position = GorillaTagger.Instance.leftHandTransform.position;

                GameObject r = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                UnityEngine.Object.Destroy(r.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(r.GetComponent<SphereCollider>());

                r.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                r.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                l.GetComponent<Renderer>().material.color = bgColorA;
                r.GetComponent<Renderer>().material.color = bgColorA;

                UnityEngine.Object.Destroy(l, Time.deltaTime);
                UnityEngine.Object.Destroy(r, Time.deltaTime);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        public static bool shouldBePC = false;
        public static Camera TPC = null;
        public static int themeType = 1;
        public static Color bgColorA = new Color32(255, 128, 0, 128);
        public static Color bgColorB = new Color32(255, 102, 0, 128);
        public static GameObject CheckPoint = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        public static void FreezeRigLimbs()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;

                GorillaTagger.Instance.offlineVRRig.transform.position = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, 0.15f, 0f);
                GorillaTagger.Instance.myVRRig.transform.position = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, 0.15f, 0f);

                GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
                GorillaTagger.Instance.myVRRig.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;

                //GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation = GorillaTagger.Instance.headCollider.transform.rotation;

                GameObject l = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                UnityEngine.Object.Destroy(l.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(l.GetComponent<SphereCollider>());

                l.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                l.transform.position = GorillaTagger.Instance.leftHandTransform.position;

                GameObject r = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                UnityEngine.Object.Destroy(r.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(r.GetComponent<SphereCollider>());

                r.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                r.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                l.GetComponent<Renderer>().material.color = bgColorA;
                r.GetComponent<Renderer>().material.color = bgColorA;

                UnityEngine.Object.Destroy(l, Time.deltaTime);
                UnityEngine.Object.Destroy(r, Time.deltaTime);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        public static void Spaz()
        {
            {
                GorillaTagger.Instance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360));
                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360));
                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360));
                GorillaTagger.Instance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 180), (float)UnityEngine.Random.Range(0, 180));
                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 180), (float)UnityEngine.Random.Range(0, 180));
                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 180), (float)UnityEngine.Random.Range(0, 180));
            }
        }
        public static void NuhUhWeirdHead()
        {
            RigShit.GetOwnVRRig().head.trackingRotationOffset.z = 0f;
        }

        public static void nuhuhHandSpin1()
        {
            RigShit.GetOwnVRRig().rightHand.trackingRotationOffset.z = 20f;
            RigShit.GetOwnVRRig().leftHand.trackingRotationOffset.z = -20f;

        }
        public static void HandSpin1()
        {
            RigShit.GetOwnVRRig().rightHand.trackingRotationOffset.z += 15f;
            RigShit.GetOwnVRRig().leftHand.trackingRotationOffset.z += 15f;
        }


        public static void CursedGrabHead()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                GorillaTagger.Instance.offlineVRRig.headMesh.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position;
            }
            if (ControllerInputPoller.instance.leftGrab)
            {
                GorillaTagger.Instance.offlineVRRig.headMesh.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
            }
            
        }

        public static void FixHeadForGrabHead()
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
            GorillaTagger.Instance.offlineVRRig.headMesh.transform.position = GorillaTagger.Instance.offlineVRRig.headMesh.transform.position;
        }

        public static void WeirdHead()
        {
            RigShit.GetOwnVRRig().head.trackingRotationOffset.z += 15f;
        }
        public static void EUServers()
        {
            PhotonNetwork.ConnectToRegion("eu"); //from frwosty 
        }

        public static void NuhUhRollMonke()
        {
            RigShit.GetOwnVRRig().head.trackingRotationOffset.x = 0;
        }
        public static void RollMonke()
        {
            RigShit.GetOwnVRRig().head.trackingRotationOffset.x += 15f;
        }

        public static void HeadSpin()
        {
            RigShit.GetOwnVRRig().head.trackingRotationOffset.y += 15f;
        }

        public static void nuhuhheadspin()
        {
            RigShit.GetOwnVRRig().head.trackingRotationOffset.y = 0.0f;

        }

        public static void BackwardsHead()
        {
            RigShit.GetOwnVRRig().head.trackingRotationOffset.y = 180f;
        }
        public static void UpsideDownHead()
        {
            RigShit.GetOwnVRRig().head.trackingRotationOffset.z = 180f;
        }

        public static void UpsideUpHead()
        {
            RigShit.GetOwnVRRig().head.trackingRotationOffset.x = 90f;
        }
    }
}
