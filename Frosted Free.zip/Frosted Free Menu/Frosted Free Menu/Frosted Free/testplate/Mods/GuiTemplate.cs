﻿using GorillaNetworking;
using Photon.Pun;
using UnityEngine;
using HarmonyLib;
using System.Reflection;
using UnityEngine.UI;
using PlayFab.ClientModels;
using UnityEngine.XR;
using BepInEx;
using System;
using static System.Net.Mime.MediaTypeNames;
using System.Diagnostics;

namespace GhostsGUI
{
    [BepInPlugin("GhostGuiTemp", "GhostsGuiTemp", "1.0.0")]
    public class GhostGUI : BaseUnityPlugin
    {
        private bool showGUI = true;
        private bool NoAFK = false;
        private bool modname1 = false;
        void OnGUI()
        {
            if (showGUI)
            {
                GUI.Box(new Rect(40, 40, 460, 360), "Ghosts GUI Temp [CTRL + P = Close]");

                GUI.color = Color.grey;
                GUI.contentColor = Color.white;

                // buttons
                if (GUI.Button(new Rect(50, 50, 100, 20), "Disconnect"))
                {
                    PhotonNetwork.Disconnect();
                }

                if (GUI.Button(new Rect(50, 70, 100, 20), "JoinPublic"))
                {
                    PhotonNetwork.JoinRandomRoom();
                }

                NoAFK = GUI.Toggle(new Rect(50, 90, 200, 20), NoAFK, "NoAFKKick");
                if (NoAFK)
                {
                    PhotonNetworkController.Instance.disableAFKKick = true;
                }

                modname1 = GUI.Toggle(new Rect(50, 110, 200, 20), modname1, "PlaceHolder");
                if (modname1)
                {
                    Keymovement();
                }





                // closing and opening gui
                Event e = Event.current;
                if (e != null && e.isKey && e.keyCode == KeyCode.P && e.control)
                {
                    showGUI = false;
                }
            }
            else
            {
                GUI.Label(new Rect(10, 10, 200, 20), "CTRL + C to open GUI");
                Event e = Event.current;
                if (e != null && e.isKey && e.keyCode == KeyCode.C && e.control)
                {
                    showGUI = true;
                }
            }
            void Keymovement()
            {
                
                bool key = UnityInput.Current.GetKey(KeyCode.W);
                if (key)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 5f;
                }
                bool key2 = UnityInput.Current.GetKey(KeyCode.S);
                if (key2)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * -5f;
                }
                bool key3 = UnityInput.Current.GetKey(KeyCode.D);
                if (key3)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.right * Time.deltaTime * 5f;
                }
                bool key4 = UnityInput.Current.GetKey(KeyCode.A);
                if (key4)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.right * Time.deltaTime * -5f;
                }
                bool key5 = UnityInput.Current.GetKey(KeyCode.Q);
                if (key5)
                {
                    GorillaLocomotion.Player.Instance.transform.Rotate(0f, -1f, 0f);
                }
                bool key6 = UnityInput.Current.GetKey(KeyCode.E);
                if (key6)
                {
                    GorillaLocomotion.Player.Instance.transform.Rotate(0f, 1f, 0f);
                }
                bool key7 = UnityInput.Current.GetKey(KeyCode.LeftShift);
                if (key7)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.up * Time.deltaTime * -5f;
                }
                bool key8 = UnityInput.Current.GetKey(KeyCode.Space);
                if (key8)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.up * Time.deltaTime * 5f;
                }
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }
    }
    }
